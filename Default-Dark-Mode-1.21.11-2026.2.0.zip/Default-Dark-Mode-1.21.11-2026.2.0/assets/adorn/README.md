<img src="icon.png" align="left" width="180px"/>

# Adorn

[![](https://img.shields.io/github/license/Juuxel/Adorn.svg)](LICENSE) [![](https://img.shields.io/github/release/Juuxel/Adorn.svg)](https://github.com/Juuxel/Adorn/releases) ![](http://cf.way2muchnoise.eu/versions/minecraft_adorn_all.svg) [![](http://cf.way2muchnoise.eu/adorn.svg)](https://minecraft.curseforge.com/projects/adorn)

*Decorate your home!* • [Downloads](https://github.com/Juuxel/Adorn/releases) • [CurseForge](https://minecraft.curseforge.com/projects/adorn)

<p>&nbsp;</p>

## Screenshots
![](https://i.imgur.com/tQbDWVY.jpg)
![](https://i.imgur.com/lUifqTY.png)
![](https://i.imgur.com/owM5tUa.png)
